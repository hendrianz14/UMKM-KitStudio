export function generatePalette(primary: string) {
  return {
    primary,
    primaryLight: primary + "33",
    primaryDark: primary + "cc",
  };
}