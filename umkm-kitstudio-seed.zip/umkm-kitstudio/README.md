# UMKM KitStudio (Seed Project)

Full-stack SaaS starter dengan Next.js + Supabase + Tailwind + shadcn/ui.

## 🚀 Jalankan Lokal
```bash
pnpm install
pnpm dev
```

## ⚙️ ENV
Salin `.env.example` → `.env.local` dan isi dengan key Supabase, n8n, dan Midtrans/Xendit.

## 📦 Stack
- Next.js 14 App Router
- Supabase (auth, db, storage)
- TailwindCSS + shadcn/ui
- Vitest untuk unit test
