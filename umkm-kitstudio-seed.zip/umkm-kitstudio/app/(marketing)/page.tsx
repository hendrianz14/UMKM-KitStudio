export default function LandingPage() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen text-center">
      <h1 className="text-4xl font-bold">UMKM KitStudio</h1>
      <p className="mt-4 text-gray-500">Bangun konten profesional dari foto produk sederhana.</p>
      <div className="mt-6 flex gap-4">
        <a href="/login" className="px-4 py-2 bg-blue-600 text-white rounded-lg">Coba Gratis</a>
        <a href="#demo" className="px-4 py-2 border border-gray-300 rounded-lg">Lihat Demo</a>
      </div>
    </main>
  )
}