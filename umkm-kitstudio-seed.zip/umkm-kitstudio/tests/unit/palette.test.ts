import { describe, it, expect } from "vitest";
import { generatePalette } from "../../lib/utils";

describe("Palette generator", () => {
  it("should create lighter and darker shades", () => {
    const palette = generatePalette("#ff0000");
    expect(palette.primary).toBe("#ff0000");
    expect(palette).toHaveProperty("primaryLight");
    expect(palette).toHaveProperty("primaryDark");
  });
});